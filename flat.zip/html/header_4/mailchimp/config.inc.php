<?php

// API Key - see http://admin.mailchimp.com/account/api
$apikey = 'f63ce6a16a8ec09cfb166d444e1a48ae-us10'; // YOUR MAILCHIMP APIKEY

// A List Id to run examples against. use lists() to view all
// Also, login to MC account, go to List, then List Tools, and look for the List ID entry
$listId = '657ea6b874'; // YOUR MAILCHIMP LIST ID - see lists() method

// A Campaign Id to run examples against. use campaigns() to view all
$campaignId	= ''; // YOUR MAILCHIMP CAMPAIGN ID - see campaigns() method
